# Pet_Place_26-10-24
Learn how to build a fully responsive pet store website from scratch using HTML, CSS, and JavaScript!
